Dear Readers.

   If you use the code for this algorithm, please cite this paper. 

    Z. Hu, J. Wang, K. Zhang, W. Pedrycz and N. R. Pal,��Bi-level spectral feature selection,��IEEE Transactions on Neural Networks and Learning Systems, in press, 2024, doi: 10.1109/TNNLS.2024.3408208.


    Thanks very much. If you have any question about this code, please contact the author Jian Wang (wangjiannl@upc.edu.cn) and Zebiao Hu (zebiao@s.upc.edu.cn).


Best regads.



