% % %  Written by Jian Wang (wangjiannl@upc.edu.cn) and Zebiao Hu (zebiao@s.upc.edu.cn)
function [index] = BLSFS(X,c,beta,gamma)
%OPTIMIZE �˴���ʾ�йش˺�����ժҪ

[d,n] = size(X);
X = NormalizeFea(full(X),1);
%% parameter setting
eps = 1e-5;
% s = 50;   

maxiter = 20; 
%% construct similarity matrix

D = EuDist2(X');   
optt = mean(D(:)); %
options.NeighborMode = 'KNN';       
options.WeightMode = 'HeatKernel'; 
options.k = 10;  
options.t = optt; 
S = constructW(X',options);


D = diag(sum(S, 2));
L = D - S;
% L(isnan(L)) = 0; D(isnan(D)) = 0;
% L(isinf(L)) = 0; D(isinf(D)) = 0;



dd = sqrt(1./max(sum(S,2),eps));  
NS = sparse(diag(dd)*S*diag(dd));
% clear L vec;


Y = zeros(c,n);
for i = 1:n
    idxr = randi(c); 
    Y(idxr,i) = 1;
end
% Y = sparse(Y);       

b = zeros(c,1);

d1 = ones(d,1);
Gamma = 2*spdiags(d1,0,d,d); 
for i = 1:maxiter
    
    tmp1 = Y*NS;
    alpha = 1./sum(sum(tmp1*Y')); 
    clear tmp1;
    p = OptimizeP(X);
    p = (p + p')/2;
    LL = diag(sum(p)) - p;
    LP = (LL + LL') / 2;
    W = OptimizeW(X,Y,LP,Gamma,b,alpha,beta,gamma);
    b = (Y - W'*X)*ones(n,1);
    Gamma = sqrt(sum(W.^2,2) + eps);
    WX = W'*X;
    Y = OptimizeY(Y,WX,NS,b);
    
end

% % %% ����||wi||2 ���������н�������
WI = sqrt(sum(W.*W,2)); 
[~,index] = sort(WI,'descend');

%% ��������ѡ���� 
% result = zeros(s,n);
% 
% for i = 1:s
%     result(i,:) = X(index(i,:),:);
% end

end

