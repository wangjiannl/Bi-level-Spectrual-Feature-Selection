function [ p ] = OptimizeP(X)


if ~exist('options', 'var')
    options = [];
end

if ~isfield(options, 'lambda')
    options.lambda = 1;
end

if ~isfield(options, 'Localk')
    options.Localk = 20; 
end

if ~isfield(options, 'LocalReg')
    options.LocalReg = estimateReg(X, options.Localk);
end

if ~isfield(options, 'maxiter')
    options.maxiter = 1;
end
[~,nSmp] = size(X);
X2 = X;

for iter = 1:options.maxiter
    if (options.maxiter < 5 || iter > 1)
        P = zeros(nSmp);
            if iter > 1
                distx = L2_distance_1(X2, X2);
                if iter > 0
                    [~, idx1] = sort(distx,2);
                end
                
                for iSmp = 1 : nSmp
                    if options.Localk < nSmp
                        idxa0 = idx1(iSmp, 2: options.Localk + 1);
                    else
                        idxa0 = 1 : nSmp;
                    end
                    dxi = distx(iSmp, idxa0);
                    ad = - (dxi) / (2 * options.LocalReg);
                    P(iSmp, idxa0) = EProjSimplex_new(ad);
                end
            else
                P = constructW(X2', struct('k', options.Localk));
            end
            P = (P + P')/2;
            LL = diag(sum(P)) - P;
            LL = (LL + LL') / 2;
        else
            LL = 0;
    end
end

function [x, ft] = EProjSimplex_new(v, k)

if nargin < 2
    k = 1;
end

ft = 1;
n = length(v);

v0 = v - mean(v) + k/n;
%vmax = max(v0);
vmin = min(v0);
if vmin < 0
    f = 1;
    lambda_m = 0;
    while abs(f) > 10^-10
        v1 = v0 - lambda_m;
        posidx = v1 > 0;
        npos = sum(posidx);
        g = -npos;
        f = sum(v1(posidx)) - k;
        lambda_m = lambda_m - f/g;
        ft = ft+1;
        if ft > 100
            x = max(v1,0); %#ok
            break;
        end
    end
    x = max(v1,0);
    
else
    x = v0;
end
end


function dist = L2_distance_1(a,b)

if (size(a,1) == 1)
    a = [a; zeros(1,size(a,2))];
    b = [b; zeros(1,size(b,2))];
end

aa = sum(a.*a); 
bb = sum(b.*b); 
ab = a'*b;
dist = repmat(aa',[1 size(bb,2)]) + repmat(bb,[size(aa,2) 1]) - 2*ab;

dist = real(dist);
dist = max(dist,0);
end 

function r = estimateReg(X, k)
[~, n] = size(X);
distX = L2_distance_1(X,X);
%distX = sqrt(distX);
[distX1, idx] = sort(distX,2);
A = zeros(n);
rr = zeros(n,1);
for j = 1:n
    di = distX1(j,2:k+2);
    rr(j) = 0.5*(k*di(k+1) - sum(di(1:k)));
    id = idx(j,2:k + 2);
    A(j,id) = (di(k + 1) - di)/(k*di(k+1) - sum(di(1:k)) + eps);
end
r = mean(rr);
end
p = LL;
end