function [ Y ] = OptimizeY(Y,WX,NS,b)
%OPTIMIZEY �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[c,n] = size(WX);
maxiter = 2;
WX = WX + b*ones(1,n);   
c0 = sum(sum((WX - Y).^2)); 
tempYS = Y*NS;  
c3 = sum(sum(tempYS*Y')); 
tmp = sum(Y); 
for i = 1:maxiter
    YYY = Y;
    for j = 1:n
        idx_last = find(Y(:,j) ==1);
        c1 = c0 - sum((WX(:,j) - Y(:,j)).^2); 
        c2 = sum((eye(c) - repmat(WX(:,j),1,c)).^2,2); 
        c4 = 2.*(tempYS(:,j) - tempYS(idx_last,j));
        c5 = 2.*NS(j,j);
        obj = (c1 + c2)./(c3 + c4 + c5);
        [~,minobj] = min(obj);
        if minobj ~= idx_last
            Y(idx_last,j) = 0;
            Y(minobj,j) = 1;
            c0 = c1 + sum((WX(:,j) - Y(:,j)).^2);
            tempYS([minobj,idx_last],:) = tempYS([minobj,idx_last],:) + [ones(1,n);-1.*ones(1,n)].*[NS(j,:);NS(j,:)];
            c3 = sum(sum(tempYS*Y'));
        end
        tmp(minobj) = tmp(minobj) + 1;
    end
    if sum(sum(abs(YYY - Y))) == 0
        break;
    end
end
        
        
end

        

